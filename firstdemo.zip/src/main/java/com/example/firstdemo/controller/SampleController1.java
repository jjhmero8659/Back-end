package com.example.firstdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SampleController1 {
	
	@GetMapping("/user/userinfo") // 단순 요청
	public String userInfo() {
		return "/user/userinfo";
	}
	
	@GetMapping("/user/userdata")
	public String userData(Model model) { //model의 Data가 자동으로 View 화면 단으로 이동한다
		model.addAttribute("userName", "장준혁"); //직접 전달
		
		return "/user/userinfo";
	}
	
	@GetMapping("/user/userid")
	public String userId(@RequestParam(value = "userid", required=false) String id, Model model) {
		//하나의 파라미터 만 지정
		model.addAttribute("userid", id);
		
		return "/user/userinfo"; //userinfo.html
	}
	
	@GetMapping("/user/userparams")
	public String userParams(
			@RequestParam(value = "userid", required=false) String id,
			@RequestParam(value = "username", required=false) String name,
			@RequestParam(value = "useremail", required=false) String email,
			@RequestParam(value = "userhp", required=false) String hp,
			Model model) {
		
		model.addAttribute("userid", id);
		model.addAttribute("username", name);
		model.addAttribute("useremail", email);
		model.addAttribute("userhp", hp);
		
		return "/user/userparams"; //userparams.html
	}
}







