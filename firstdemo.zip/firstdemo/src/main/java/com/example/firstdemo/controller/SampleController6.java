package com.example.firstdemo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.firstdemo.dto.BoardDTO;

@Controller
public class SampleController6 {
	
	@GetMapping("/SampleController6")
	public String mainPage(
			Model model) {
		
		BoardDTO boardDTO = new BoardDTO(1,"boardDTO 객체 입니다.","단일객체");
		
		BoardDTO b1 = new BoardDTO(1,"b1 객체 입니다.","홍길동");
		BoardDTO b2 = new BoardDTO(2,"b2 객체 입니다.","이순신");
		BoardDTO b3 = new BoardDTO(3,"b3 객체 입니다.","임꺽정");
		BoardDTO b4 = new BoardDTO(4,"b4 객체 입니다.","김시민");
		BoardDTO b5 = new BoardDTO(5,"b5 객체 입니다.","강감찬");
		
		List<BoardDTO> bList = new ArrayList<>();
		bList.add(b1);
		bList.add(b2);
		bList.add(b3);
		bList.add(b4);
		bList.add(b5);
		
		model.addAttribute("boardDTO", boardDTO);
		model.addAttribute("bList", bList);
		
		return "/post/SampleController6";
	}
	
}

