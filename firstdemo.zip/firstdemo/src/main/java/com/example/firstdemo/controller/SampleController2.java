package com.example.firstdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SampleController2 {
	
//	@GetMapping("/post")
//	public String demoPost() {
//		return "/post/post";
//	}
	
//	@PostMapping("/post")
//	public String postMapping(@RequestBody String req , Model model) {
//		model.addAttribute("req" , req);
//		
//		return "/post/post";
//	}
	
	@PostMapping("/post")
	public String postMapping(
			@RequestParam String membername , 
			@RequestParam String memberid , 
			Model model) {
		model.addAttribute("membername" , membername);
		model.addAttribute("memberid" , memberid);
		return "/post/post";
	}
}
