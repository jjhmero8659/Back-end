package com.example.firstdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.firstdemo.dto.BookDTO;

@Controller
public class SampleController5 {
	@GetMapping("/SampleController5Form")
	public String insertBook(Model model) {
		
		model.addAttribute("bookDTO", new BookDTO());
		
		return "/post/SampleController5Form";
	}
	
	@PostMapping("/SampleController5View")
	public String insertView(
			BookDTO bookDTO,
			Model model
			) {
		
		model.addAttribute("bookDTO", bookDTO);
		
		return "/post/SampleController5View";
	}
}

