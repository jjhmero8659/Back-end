package com.example.firstdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.firstdemo.dto.UserDTO;

@Controller
public class SampleController3 {
	
//	@PostMapping("/SampleController3")
//	public String userForm(
//			@RequestParam String userName,
//			@RequestParam String userId,
//			String userPhone //@RequestParam 은 생략이 가능하다
//			) { 
//		
//		System.out.println(userName);
//		System.out.println(userId);
//		System.out.println(userPhone);
//		
//		return "/post/SampleController3View";
//	}
	
	@PostMapping("/SampleController3")
	public String userForm(
			UserDTO userDTO, //spring boot에서 자동 mapping
			Model model) {
		
		System.out.println(userDTO.toString());
		
		model.addAttribute("userName",userDTO.getUserName());
		model.addAttribute("userId",userDTO.getUserId());
		model.addAttribute("userPhone",userDTO.getUserPhone());
		
		return "/post/SampleController3View";
	}
}




