package com.example.firstdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.firstdemo.dto.UserDTO;

@Controller
public class SampleController4 {
	
	@GetMapping("/SampleController4Form")
	public String mainPage() {
		return "/post/SampleController4Form";
	}
	
	@PostMapping("/SampleController4View")
	public String userForm(
			UserDTO userDTO,
			Model model) {
		
		model.addAttribute("userName",userDTO.getUserName());
		model.addAttribute("userId",userDTO.getUserId());
		model.addAttribute("userPhone",userDTO.getUserPhone());
		
		return "/post/SampleController4View";
	}
}
