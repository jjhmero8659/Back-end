package com.testboard2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Testboard2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
