package com.testboard2;

public class MapperTests {

}
