package com.testboard2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Testboard2Application {

	public static void main(String[] args) {
		SpringApplication.run(Testboard2Application.class, args);
	}

}
