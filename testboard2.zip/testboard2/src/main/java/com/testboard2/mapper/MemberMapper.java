package com.testboard2.mapper;

public interface MemberMapper {

}
