package com.testboard2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.testboard2.dto.MemberDTO;
import com.testboard2.service.MemberService;

@Controller
public class MemberController {
	/*
	 * 
	 */
	@Autowired
	private MemberService memberService;
	
	
	/*
	 * 회원 등록 Form 페이지 + 회원 수정 Form
	 */
	@GetMapping("/member/memberWriteForm")
	public String memberWriteForm() {
		
		return "member/memberWriteForm"; //memberWriteForm.html
	}
	
	/*
	 * 회원 등록 OK처리
	 */
	@PostMapping("/member/memberWriteOK")
	public String insertMember(MemberDTO memDTO) {

		memberService.insertMember(memDTO);
		
		return "redirect:/";
	}
}
