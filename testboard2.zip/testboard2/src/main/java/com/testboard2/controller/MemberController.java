package com.testboard2.controller;

public class MemberController {

}
