package com.testboard2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.testboard2.dto.MemberDTO;
import com.testboard2.service.MemberService;

@Controller
public class MemberController {
	/*
	 * DI
	 */
	@Autowired
	private MemberService memberService;
	
	
	/*
	 * 회원 등록 Form 페이지 + 회원 수정 Form
	 */
	@GetMapping("/member/memberWriteForm")
	public String memberWriteForm(
			@RequestParam( value="num", required = false) Integer num,
			Model model) {
		
			//required 옵션은 디폴트가 true, 써놓지 않으면 디폴트가 true로 적용
			//기본값 true로 사용하는 경우 ==> 보통 줄여서 @RequestParam("num")
			//Primitive Type(원시타입)인 int 는 null일 수 없음.
			//null이 필요한 경우 Integer 사용
		
		if(num != null) {
			MemberDTO uptMem = memberService.getMemberOne(num);

			model.addAttribute("memberDTO", uptMem);
			model.addAttribute("formTitle", "Modification");

		}

		return "member/memberWriteForm"; //memberWriteForm.html	
	}
	
	/*
	 * 회원 등록 OK처리
	 */
	@PostMapping("/member/memberWriteOK")
	public String insertMember(MemberDTO memDTO) {

		memberService.insertMember(memDTO);
		
		return "redirect:/";
	}
}
