package com.testboard2.service;

public interface MemberService {

}
