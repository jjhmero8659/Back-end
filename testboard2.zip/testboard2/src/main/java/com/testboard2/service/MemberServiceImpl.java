package com.testboard2.service;

public class MemberServiceImpl {

}
