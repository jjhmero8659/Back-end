import React, {Component} from "react";

class Post extends Component{
    constructor(props){
        super(props)

        this.state = {

        }
    }

    render(){
        return(
            <div id="Post_wrap">

            </div>
        )
    }
}

export default Post;