import React,{Component} from "react";
import "./css/DropDown.css";
import jquery from 'jquery';
import $ from 'jquery';


class DropDown extends Component{
  constructor(props){
    super(props)

    this.state = {

    }
  }

  componentDidMount(){
    let Drop_down = document.getElementById("DropDown_wrap")
    let sub_element = document.getElementsByClassName("sub")
    let blank_element = document.getElementsByClassName("blank")[0]
    console.log(sub_element)
    Drop_down.addEventListener("mouseover", function (event) {
      blank_element.style.display = "block"
      blank_element.style.height = "280px"
      for(let i=0; i<sub_element.length; i++){
        sub_element[i].style.display = "block"
        sub_element[i].style.height = "280px"
      }
    }, false);

    Drop_down.addEventListener("mouseout", function (event) {
      blank_element.style.display = "none"
      blank_element.style.height = "0px"
      for(let i=0; i<sub_element.length; i++){
        sub_element[i].style.display = "none"
        sub_element[i].style.height = "0px"
      }
    }, false);
    // $(function(){ 
    //   $("#DropDown_wrap").hover(
    //     function(e){
    //       e.stopImmediatePropagation();
    //       $(".sub , .blank").stop().slideToggle(200)
    //     }
    //   )
    // })
  }
  test = () => {
    window.location.href = "/search"
  }

  jump_Drop_down = (view) => {
    window.location.href = `/Drop_Down/product?view=${view}`
  }

  render(){
    return(
      <div id="DropDown_wrap">
        <ul className="gnb">
            <li><a>테크</a></li>
            <ul className="sub">
              <li><a onClick={()=>this.jump_Drop_down("notebook")}>노트북</a></li>
              <li><a onClick={()=>this.jump_Drop_down("tv")}>TV</a></li>
              <li><a onClick={()=>this.jump_Drop_down("wireless_earphones")}>무선 이어폰</a></li>
              <li><a onClick={()=>this.jump_Drop_down("smart_watch")}>스마트 워치</a></li>
              <li><a onClick={()=>this.jump_Drop_down("smartphone")}>스마트 폰</a></li>
              <li><a onClick={()=>this.jump_Drop_down("tap_ipad")}>탭/패드</a></li>
            </ul>
        </ul>
        <ul className="gnb">
            <li><a>생활가전</a></li>
            <ul className="sub">
              <li><a onClick={()=>this.jump_Drop_down("Wireless_cleaner")}>무선 청소기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("robotic_vacuum")}>로봇 청소기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("air_conditioner")}>공기 청정기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("dryer")}>건조기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("washing_machine")}>세탁기</a></li>
            </ul>
        </ul>
        <ul className="gnb">
            <li><a>계절가전</a></li>
            <ul className="sub">
              <li><a onClick={()=>this.jump_Drop_down("humidifier")}>가습기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("air_conditioner")}>에어컨</a></li>
              <li><a onClick={()=>this.jump_Drop_down("fan")}>선풍기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("dehumidifier")}>제습기</a></li>
            </ul>
        </ul>
        <ul className="gnb">
            <li><a>주방가전</a></li>
            <ul className="sub">
              <li><a onClick={()=>this.jump_Drop_down("blender")}>믹서기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("rice_cooker")}>전기밥솥</a></li>
              <li><a onClick={()=>this.jump_Drop_down("air_fryer")}>에어프라이어</a></li>
              <li><a onClick={()=>this.jump_Drop_down("dish_washer")}>식기 세척기</a></li>
              <li><a onClick={()=>this.jump_Drop_down("refrigerator")}>냉장고</a></li>
              <li><a onClick={()=>this.jump_Drop_down("kimchi_refrigerator")}>김치 냉장고</a></li>
            </ul>
        </ul>
        <div className="blank"></div>
      </div>
    )
  }
}

export default DropDown;