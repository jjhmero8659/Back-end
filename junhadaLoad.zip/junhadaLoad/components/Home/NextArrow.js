import React , {Component} from "react";

class NextArrow extends Component{
    constructor(props){
        super(props);

        this.state={}
    }

    render(){
        return(
            <div className="Next_Arrow">

            </div>
        )
    }
}

export default NextArrow;