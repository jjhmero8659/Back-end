import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/User_Login_Screen.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function User_Login_Screen(props){

    // const [Login_status , set_Login_status] = useState(false)
    const [user_id,set_id] = useState("");
    const [user_pw,set_pw] = useState("");
    const [user_info,set_userinfo] = useState([]);
    const [active_status,set_active_status] = useState(false);
    const [select_mode,set_select_mode] = useState("member");

    const check_log_info = async() => {
        const res = await axios.get(`/api/check/user_login${user_id}&${user_pw}`);
        if(res.data.User_info.length == 0){
            alert("ID 또는 Password 가 틀렸습니다.")
        }
        else{
            window.sessionStorage.setItem("user_name",res.data.User_info[0].name);
            window.sessionStorage.setItem("user_id",user_id);
            window.sessionStorage.setItem("user_pw",user_pw);

            window.location.href = "/";
        }
    }

    const onchange_id = (e) => {
        set_id(e.target.value)
    }

    const onchange_pw = (e) => {
        set_pw(e.target.value)
    }

    // useEffect(()=>{
        
    // },[check_log_info()])
    const settings = {
        fade : true,
        dots: false,
        autoplay:true,
        infinite: true,
        arrows:false,
        speed: 700,
        slidesToShow: 1,
        slidesToScroll: 1,
        pauseOnHover:false,
    };


    return(
        <div id="User_Login_Screen_wrap">

            <Slider {...settings}>
                    <div className="par_img_div">
                        <img src={`/img/Login/login_fade1.jpg`}></img>
                    </div>
                    <div className="par_img_div">
                        <img src={`/img/Login/login_fade2.jpg`}></img>
                    </div>
                    <div className="par_img_div">
                        <img src={`/img/Login/login_fade3.jpg`}></img>
                    </div>
            </Slider>

            
            <div className="Login" >
                
                <div id="input_wrap" className="member">
                    <div className="top_area">
                        Login
                    </div>

                    <input className="input_id" type="text" placeholder="아이디 를 입력해주세요" onChange={(e)=>onchange_id(e)}></input>
                    <input className="input_pw" type="password" placeholder="비밀번호 를 입력해주세요" onChange={(e)=>onchange_pw(e)}></input>
                    
                    <div className="maintain_status_wrap">
                        <div id="maintain_status" className={(active_status == true) ? "active" : null} onClick={()=>set_active_status(!active_status)}>
                            <div className="icon"></div>
                            <p>로그인 상태 유지하기</p>
                        </div>
                    </div>
                    <div className="sub_menu">
                        <div className="find_id">Find ID</div>
                        <div className="find_pw">Find PW</div>
                        <div className="join_membership">Join Membership</div>
                    </div>
                    <div className="Login_btn" onClick={()=>check_log_info()}>
                        로그인
                    </div>
                    
                </div>
                
            </div>
           
            <div className="right_menu">
                <div className="right_find_id">Find ID</div>
                <div className="right_find_pw">Find PW</div>
                <div className="right_join_membership">Join Membership</div>
                <div className="right_kakao">Kakao Login</div>
                <div className="right_naver">Naver Login</div>
                <div className="right_daum">Daum Login</div>
            </div>
        </div>
    )
}

export default User_Login_Screen;