import axios from "axios";
import React , {useEffect, useState} from "react";
import "./css/Best_Product.css";
// import Best_Post from "./Best_Product/Post.js";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function Best_Product(props){

    const [Product,set_Product] = useState(props.Product)
    const [Represent_data,set_Represent_data] = useState(null)

    useEffect(()=>{
        Representative_review();
    },[])

    const Representative_review = async() => {
        const res = await axios.get(`/api/get_represent/get_product`)
        set_Represent_data(res.data.data)
    }


    const Best_pro_settings = {
        fade : true,
        dots: false,
        autoplay:true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
    };
// http://localhost:3000/review_board/detail?pro_id=7701&user_name=DiaNa&title=LG%EA%B7%B8%EB%9E%A8%2017%EC%9D%B8%EC%B9%98%20%EC%8B%A4%EC%82%AC%EC%9A%A9%20%ED%9B%84%EA%B8%B0&view=NoteBook&create_time=22_13_50
// http://localhost:3000/review_board/detail?pro_id=7701&user_name=Admin&title=LG%EC%A0%84%EC%9E%90%20%EA%B7%B8%EB%9E%A8%2020%EB%85%84%ED%98%95%2017%EC%9D%B8%EC%B9%98%20i5&view=NoteBook&create_time=22_13_50

// http://localhost:3000/review_board/detail?pro_id=7701&user_name=DiaNa&title=LG%EC%A0%84%EC%9E%90%20%EA%B7%B8%EB%9E%A8%2020%EB%85%84%ED%98%95%2017%EC%9D%B8%EC%B9%98%20i5&view=NoteBook&create_time=22_13_50
    const jump_first_review_detail = () => {
        window.location.href=`/review_board/detail?pro_id=${Represent_data[0].pro_id}&user_name=${Represent_data[0].writer}&title=${Represent_data[0].title}&view=${Represent_data[0].view}&create_time=${Represent_data[0].time}`
    }
    const jump_second_review_detail = () => {
        window.location.href=`/review_board/detail?pro_id=${Represent_data[1].pro_id}&user_name=${Represent_data[1].writer}&title=${Represent_data[1].title}&view=${Represent_data[1].view}&create_time=${Represent_data[1].time}`
    }
    const jump_third_review_detail = () => {
        window.location.href=`/review_board/detail?pro_id=${Represent_data[2].pro_id}&user_name=${Represent_data[2].writer}&title=${Represent_data[2].title}&view=${Represent_data[2].view}&create_time=${Represent_data[2].time}`
    }
    return(
        <div id="Best_Product_wrap">
            <div className="header">
                베스트 상품평
            </div>
            {Represent_data && <div className="Posts_wrap">
                <Slider {...Best_pro_settings}>
                    <div id="Best_review_first_div" className="Best_review_wrap">
                        <div className="product_model_txt">
                            {Represent_data[0].title}
                            <div className="review_writer_div">
                                {Represent_data[0].writer} 님
                            </div>
                        </div> 
                        <div className="profile_img">
                            <div className="profile_img_first">
                                <img src={`${Represent_data[0].src1}`}></img>
                            </div>
                            <div className="profile_img_second">
                                <img src={`${Represent_data[0].src2}`}></img>
                            </div>
                            <div className="profile_img_third">
                                <img src={`${Represent_data[0].src3}`}></img>
                            </div>
                            <div className="profile_img_forth">
                                <img src={`${Represent_data[0].src4}`}></img>
                            </div>
                            <div className="profile_img_fifth">
                                <img src={`${Represent_data[0].src5}`}></img>
                            </div>
                        </div>
                        <div className="summary_div">
                            {Represent_data[0].summary}
                        </div>
                        <div className="rec_div">
                            <div className="good_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[0].good_rec}
                                </div>
                            </div>

                            <div className="bad_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[0].bad_rec}
                                </div>
                            </div>
                        </div>
                        <div className="detail_btn" onClick={()=>jump_first_review_detail()}>
                            자세히 보기
                        </div> 
                    </div>
                    <div id="Best_review_second_div" className="Best_review_wrap">
                        <div className="product_model_txt">
                            {Represent_data[1].title}
                            <div className="review_writer_div">
                                {Represent_data[1].writer} 님
                            </div>
                        </div> 
                        <div className="profile_img">
                            {(Represent_data[1].src1 != "") && <div className="profile_img_first">
                                <img src={`${Represent_data[1].src1}`}></img>
                            </div>}
                            {(Represent_data[1].src2 != "") && <div className="profile_img_second">
                                <img src={`${Represent_data[1].src2}`}></img>
                            </div>}
                            {(Represent_data[1].src3 != "") && <div className="profile_img_third">
                                <img src={`${Represent_data[1].src3}`}></img>
                            </div>}
                            {(Represent_data[1].src4 != "") && <div className="profile_img_forth">
                                <img src={`${Represent_data[1].src4}`}></img>
                            </div>}
                            {(Represent_data[1].src5 != "") && <div className="profile_img_fifth">
                                <img src={`${Represent_data[1].src5}`}></img>
                            </div>}
                        </div>
                        <div className="summary_div">
                            {Represent_data[1].summary}
                        </div>
                        <div className="rec_div">
                            <div className="good_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[1].good_rec}
                                </div>
                            </div>

                            <div className="bad_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[1].bad_rec}
                                </div>
                            </div>
                        </div>
                        <div className="detail_btn" onClick={()=>jump_second_review_detail()}>
                            자세히 보기
                        </div> 
                    </div>
                    <div id="Best_review_third_div" className="Best_review_wrap">
                    <div className="product_model_txt">
                            {Represent_data[2].title}
                            <div className="review_writer_div">
                                {Represent_data[2].writer} 님
                            </div>
                        </div> 
                        <div className="profile_img">
                            {(Represent_data[2].src1 != "") && <div className="profile_img_first">
                                <img src={`${Represent_data[2].src1}`}></img>
                            </div>}
                            {(Represent_data[2].src2 != "") && <div className="profile_img_second">
                                <img src={`${Represent_data[2].src2}`}></img>
                            </div>}
                            {(Represent_data[2].src3 != "") && <div className="profile_img_third">
                                <img src={`${Represent_data[2].src3}`}></img>
                            </div>}
                            {(Represent_data[2].src4 != "") && <div className="profile_img_forth">
                                <img src={`${Represent_data[2].src4}`}></img>
                            </div>}
                            {(Represent_data[2].src5 != "") && <div className="profile_img_fifth">
                                <img src={`${Represent_data[2].src5}`}></img>
                            </div>}
                        </div>
                        <div className="summary_div">
                            {Represent_data[2].summary}
                        </div>
                        <div className="rec_div">
                            <div className="good_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[2].good_rec}
                                </div>
                            </div>

                            <div className="bad_rec_wrap">
                                <div className="img_div">
                                    
                                </div>
                                <div className="rec_num_txt">
                                    {Represent_data[2].bad_rec}
                                </div>
                            </div>
                        </div>
                        <div className="detail_btn" onClick={()=>jump_third_review_detail()}>
                            자세히 보기
                        </div> 
                    </div>
                    {/* <div id="Best_review_first_div" className="Best_review_wrap">
                        4
                    </div>
                    <div id="Best_review_first_div" className="Best_review_wrap">
                        
                    </div> */}
                </Slider>
            </div>}
        </div>
    )
}

export default Best_Product;