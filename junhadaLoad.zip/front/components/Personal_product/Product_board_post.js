import React , {useEffect, useState} from "react";
import "./css/Product_board_post.css";
import User_img from "../Home/img/user_img.png";
import axios from "axios";

function Product_board_post(props){
    console.log("board_post1212",props)
    const [user_img,set_user_img] = useState([])
    // const jump_board_page = () => {
    //     window.location.href = "/review_board?pro_id="+props.product_id;
    // }

    const jump_board_detail = async() => {
        let Obj = {
            id : props.product_id,
            name : props.data.name,
            title : props.data.title,
            time : props.data.time,
        }
        
        window.location.href = "/review_board/detail?pro_id="+props.product_id+"&user_name="+props.name+"&title="+props.data.title+"&view="+props.view+"&create_time="+props.data.time;
        const res = await axios.put(`/api/put/update_inpuiry`,Obj)
        // window.location.href = "/review_board/detail?pro_id="+props.product_id+"&user_name="+props.name+"&title="+props.data.title+"&view="+props.view+"&create_time="+props.data.time;
    }

    useEffect(()=>{
        get_user_info(props.name)
    },[])

    const get_user_info = async(data) => {
        const res = await axios.get(`/api/get/user_info_img${data}`);
        set_user_img(
            res.data.img_src[0].profile_img
        )
    } 

    return(
        <div id="Product_board_post_wrap">
            <div className="user_img">
                <img src={user_img}></img>
            </div>
            <div className="name">
                {props.name}님
            </div>
            <div className="title" onClick={()=>jump_board_detail()}>
                {props.title}
            </div>
            <div className="review_img" onClick={()=>jump_board_detail()}>
                <img src={props.review_img}></img>
            </div>
            <div className="time">
                 {props.data.date} 작성
            </div>
            <div className="good_rec_wrap">
                <div className="good_rec">
                    
                </div>
                <div className="good_rec_text">
                    {props.good_rec}
                </div>
            </div>
            {/* <div className="bad_rec_wrap">
                <div className="bad_rec">
                    
                </div>
                <div className="bad_rec_text">
                    {props.bad_rec}
                </div>
            </div> */}
            
        </div>
    )
}

export default Product_board_post;