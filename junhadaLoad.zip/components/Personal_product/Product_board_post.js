import React , {useEffect, useState} from "react";
import { useNavigate } from 'react-router-dom'; 
import "./css/Product_board_post.css";
import User_img from "../Home/img/user_img.png";
import axios from "axios";

function Product_board_post(props){
    const navigate = useNavigate();
    const [user_img,set_user_img] = useState([])

    const jump_board_detail = async() => {

        await axios(
            {
              url: '/inquiry',
              method: 'put',
              params: {
                 id : props.data.id
                ,view : props.view
              } , 
              baseURL: 'http://localhost:8024',
            }
          ).then(function (response) {
            navigate("/review_board/detail", {
                state: {
                  productId : props.data.id
                }
            });
          });
        
    }

    useEffect(()=>{
        get_user_info(props.name)
    },[])

    const get_user_info = async(data) => {
        const res = await axios.get(`/api/get/user_info_img${data}`);
        set_user_img(
            res.data.img_src[0].profile_img
        )
    } 

    return(
        <div id="Product_board_post_wrap">
            <div className="user_img">
                <img src={user_img}></img>
            </div>
            <div className="name">
                {props.data.nickName}님
            </div>
            <div className="title" onClick={()=>jump_board_detail()}>
                {props.data.title}
            </div>
            <div className="review_img" onClick={()=>jump_board_detail()}>
                <img src={props.data.review_img1}></img>
            </div>
            <div className="time">
                 {props.data.date} 작성
            </div>
            <div className="good_rec_wrap">
                <div className="good_rec">
                    
                </div>
                <div className="good_rec_text">
                    {props.data.good_rec}
                </div>
            </div>
            
        </div>
    )
}

export default Product_board_post;