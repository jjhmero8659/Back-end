import React , {useEffect, useState} from "react";
import "./css/Review_Board.css";
import queryString from "query-string";
import axios from "axios";
import Review_Board_Posts from "./Review_Board_Posts.js";
import Review_Board_ProInfo from "./Review_Board_ProInfo.js";

function Review_Board(props){ //날짜 넘겨받아야함

    const [review,setReview] = useState([])
    const [view,setView] = useState("")
    const [length,set_len] = useState(0)
    const [pro_id,set_pro_id] = useState("")
    const [pro_info,set_pro_info] = useState([])



    useEffect(()=>{
        const queryObj = queryString.parse(window.location.search) //값은 Post 에서 날아옴
        // console.log("queryObj :" ,queryObj.pro_id) //해당하는 물건의 이름
        console.log("queryObj_view :" ,queryObj.view) //해당하는 물건의 이름
        console.log("queryObj_Review_board :" ,queryObj)

        get_review_all(queryObj.pro_id)
        get_proinfo(queryObj.pro_id,queryObj.view)
        set_pro_id(
            queryObj.pro_id
        )
        setView(queryObj.view)
    },[])

    const get_proinfo = async(id,view) => {
        // console.log("data",data)
        const res = await axios.get(`/api/get/get_product${id}&${view}`);
        // console.log("get_review3" , res.data)
        set_pro_info(
            res.data.Product
        )
    }
    

    const get_review_all = async(data) => {
        // console.log("data",data)
        const res = await axios.get(`/api/get_review/get_review_all${data}`);
        // console.log("get_review3" , res.data)
        setReview(
            res.data.Review
        )
        set_len(res.data.Review.length)
    }

    const review_postinfo = pro_info.map(
        (data,index) => <Review_Board_ProInfo
            key= {index}
            data = {data}
        />
    )

    return(
        <div id="Review_Board_wrap">
            <div className="Pro_img">
                {review_postinfo}
            </div>
            <div className="review_board_head">
                {/* <div className="num">
                    번호
                </div> */}
                <div className="title">
                    제목
                </div>
                <div className="writer">
                    작성자
                </div>
                <div className="date">
                    등록일
                </div>
                <div className="inquiry">
                    조회
                </div>
            </div>
            <Review_Board_Posts
                review = {review}
                pro_id = {pro_id}
                num = {length}
                view = {view}
            />
        </div>
    )
}

export default Review_Board;