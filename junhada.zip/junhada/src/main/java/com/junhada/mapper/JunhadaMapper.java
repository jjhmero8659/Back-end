package com.junhada.mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.junhada.dto.ProductDTO;
import com.junhada.dto.ArticleDTO;
import com.junhada.dto.LoginDTO;
import com.junhada.dto.ProImageDTO;

@Mapper
public interface JunhadaMapper {
	public ProductDTO selectProOne(HashMap<String, Object> map);
	public List<ProductDTO> selectProAll(String view);
	public List<ArticleDTO> selectRepresentReview(HashMap<String, Object> map);
	public void addInquiry(HashMap<String, Object> map);
	public String getUserProfileImage(String nickName);
	public ArticleDTO getArticleInfo(Integer id);
	public List<ArticleDTO> getProArticleAll(Integer id);
	public ProImageDTO getProductImage(Integer id);
	public LoginDTO checkLogin(HashMap<String, Object> map);
}



