package com.junhada.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.junhada.dto.NotebookDTO;

@Mapper
public interface JunhadaMapper {
	public void insertMember(NotebookDTO memberdto);
	public NotebookDTO selectMemberOne(Integer num);
}



