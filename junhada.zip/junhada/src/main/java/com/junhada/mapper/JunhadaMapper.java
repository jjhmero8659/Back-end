package com.junhada.mapper;

import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;

import com.junhada.dto.PriceDTO;
import com.junhada.dto.ProductDTO;

@Mapper
public interface JunhadaMapper {
//	public void insertMember(NotebookDTO notebookDTO);
//	public NotebookDTO selectMemberOne(Integer num);
	public ProductDTO selectProOne(HashMap<String, Object> map);
	public PriceDTO selectProPrice(HashMap<String, Object> map);
}



