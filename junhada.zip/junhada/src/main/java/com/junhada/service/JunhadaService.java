package com.junhada.service;

import org.springframework.stereotype.Service;

import com.junhada.dto.NotebookDTO;


@Service
public interface JunhadaService {
	public void insertMember(NotebookDTO notebookDTO);
	public NotebookDTO getMemberOne(Integer num);
}
