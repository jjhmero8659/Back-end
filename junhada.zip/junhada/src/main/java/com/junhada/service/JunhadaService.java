package com.junhada.service;

import org.springframework.stereotype.Service;

import com.junhada.dto.PriceDTO;
import com.junhada.dto.ProductDTO;


@Service
public interface JunhadaService {
//	public void insertMember(NotebookDTO notebookDTO);
//	public NotebookDTO getMemberOne(Integer num);
	public ProductDTO getOneProduct(Integer id, String view);
	public PriceDTO getProductPrice(Integer id, String view);
}
