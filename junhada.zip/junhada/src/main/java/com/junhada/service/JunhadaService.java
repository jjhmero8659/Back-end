package com.junhada.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.junhada.dto.ProductDTO;
import com.junhada.dto.ArticleDTO;
import com.junhada.dto.ProImageDTO;


@Service
public interface JunhadaService {
	public ProductDTO getOneProduct(Integer id, String view);
	public List<ArticleDTO> getRepresentReview(Integer id, String view);
	public void addInquiry(Integer id, String view);
	public String getUserProfileImage(String nickName);
	public ArticleDTO getArticleInfo(Integer id);
	public List<ArticleDTO> getProArticleAll(Integer id);
	public ProImageDTO getProductImage(Integer id);
	public String checkLogin(String id, String password);
	public List<ProductDTO> getAllProduct(String view);
}
