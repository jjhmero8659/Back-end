package com.junhada.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.junhada.dto.ProductDTO;
import com.junhada.dto.ArticleDTO;
import com.junhada.dto.LoginDTO;
import com.junhada.dto.ProImageDTO;
import com.junhada.mapper.JunhadaMapper;

@Service
public class JunhadaServiceImpl implements JunhadaService{
	@Autowired
	private JunhadaMapper junhadaMapper;
	
	@Override
	public ProductDTO getOneProduct(Integer id, String view) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("view", view);
		return junhadaMapper.selectProOne(map);
	}

	@Override
	public List<ProductDTO> getAllProduct(String view) {
		return junhadaMapper.selectProAll(view);
	}
	
	@Override
	public List<ArticleDTO> getRepresentReview(Integer id, String view) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("view", view);
		
		return junhadaMapper.selectRepresentReview(map);
	}
	
	@Override
	public void addInquiry(Integer id, String view) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("view", view);
		junhadaMapper.addInquiry(map);
	};
	
	@Override
	public String getUserProfileImage(String nickName) {
		return junhadaMapper.getUserProfileImage(nickName);
	};
	
	@Override
	public ArticleDTO getArticleInfo(Integer id) {
		return junhadaMapper.getArticleInfo(id);
	};
	
	@Override
	public List<ArticleDTO> getProArticleAll(Integer id){
		return junhadaMapper.getProArticleAll(id);
	};
	
	@Override
	public ProImageDTO getProductImage(Integer id) {
		return junhadaMapper.getProductImage(id);
	}
		
	@Override
	public String checkLogin(String id, String password) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("passwd", password);
		LoginDTO loginDTO = junhadaMapper.checkLogin(map);
		if(loginDTO != null && id.equals(loginDTO.getId()) && password.equals(loginDTO.getPasswd())) {
			return loginDTO.getNickName();
		}
		return null;
	};
//	
//	@Override
//	public NotebookDTO getMemberOne(Integer num) {
//		return junhadaMapper.selectMemberOne(num);
//	}

}
