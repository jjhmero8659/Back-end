package com.junhada.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.junhada.dto.NotebookDTO;
import com.junhada.mapper.JunhadaMapper;

@Service
public class JunhadaServiceImpl implements JunhadaService{
	
	/*
	 * DI
	 */
	@Autowired
	private JunhadaMapper junhadaMapper;
		
	@Override
	public void insertMember(NotebookDTO notebookDTO) {
		junhadaMapper.insertMember(notebookDTO);
	};
	
	@Override
	public NotebookDTO getMemberOne(Integer num) {
		return junhadaMapper.selectMemberOne(num);
	}

}
