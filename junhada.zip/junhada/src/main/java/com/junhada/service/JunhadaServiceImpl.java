package com.junhada.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.junhada.dto.PriceDTO;
import com.junhada.dto.ProductDTO;
import com.junhada.mapper.JunhadaMapper;

@Service
public class JunhadaServiceImpl implements JunhadaService{
	@Autowired
	private JunhadaMapper junhadaMapper;

	@Override
	public ProductDTO getOneProduct(Integer id, String view) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("view", view);
		return junhadaMapper.selectProOne(map);
	}
	
	@Override
	public PriceDTO getProductPrice(Integer id, String view) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		map.put("view", view);
		return junhadaMapper.selectProPrice(map);
	}
		
//	@Override
//	public void insertMember(NotebookDTO notebookDTO) {
//		junhadaMapper.insertMember(notebookDTO);
//	};
//	
//	@Override
//	public NotebookDTO getMemberOne(Integer num) {
//		return junhadaMapper.selectMemberOne(num);
//	}

}
