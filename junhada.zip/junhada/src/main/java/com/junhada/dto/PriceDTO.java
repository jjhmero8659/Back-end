package com.junhada.dto;

public class PriceDTO {
	int id;
	String haemil;
	String wemake;
	String interpark;
	String _11st;
	String lotte;
	String auction;
	String gmarcket;
	String tmon;
	String ssg;
	String coupang;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHaemil() {
		return haemil;
	}
	public void setHaemil(String haemil) {
		this.haemil = haemil;
	}
	public String getWemake() {
		return wemake;
	}
	public void setWemake(String wemake) {
		this.wemake = wemake;
	}
	public String getInterpark() {
		return interpark;
	}
	public void setInterpark(String interpark) {
		this.interpark = interpark;
	}
	public String get_11st() {
		return _11st;
	}
	public void set_11st(String _11st) {
		this._11st = _11st;
	}
	public String getLotte() {
		return lotte;
	}
	public void setLotte(String lotte) {
		this.lotte = lotte;
	}
	public String getAuction() {
		return auction;
	}
	public void setAuction(String auction) {
		this.auction = auction;
	}
	public String getGmarcket() {
		return gmarcket;
	}
	public void setGmarcket(String gmarcket) {
		this.gmarcket = gmarcket;
	}
	public String getTmon() {
		return tmon;
	}
	public void setTmon(String tmon) {
		this.tmon = tmon;
	}
	public String getSsg() {
		return ssg;
	}
	public void setSsg(String ssg) {
		this.ssg = ssg;
	}
	public String getCoupang() {
		return coupang;
	}
	public void setCoupang(String coupang) {
		this.coupang = coupang;
	}
	@Override
	public String toString() {
		return "PriceDTO [id=" + id + ", haemil=" + haemil + ", wemake=" + wemake + ", interpark=" + interpark
				+ ", _11st=" + _11st + ", lotte=" + lotte + ", auction=" + auction + ", gmarcket=" + gmarcket
				+ ", tmon=" + tmon + ", ssg=" + ssg + ", coupang=" + coupang + "]";
	}
	
	
}
