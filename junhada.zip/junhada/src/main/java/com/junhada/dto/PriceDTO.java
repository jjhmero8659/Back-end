package com.junhada.dto;
import lombok.*;

@Setter
@Getter
@ToString
public class PriceDTO {
	int id;
	String haemil;
	String wemake;
	String interpark;
	String _11st;
	String lotte;
	String auction;
	String gmarcket;
	String tmon;
	String ssg;
	String coupang;

}
