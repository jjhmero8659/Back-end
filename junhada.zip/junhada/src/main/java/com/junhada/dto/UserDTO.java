package com.junhada.dto;

public class UserDTO {

}
