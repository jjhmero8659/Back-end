package com.junhada.dto;


public class NotebookDTO {
	int id;
	int ranking;
	String name;
	double gpa;
	String pExplan_image1;
	String pExplan_image2;
	String pExplan_image3;
	String pro_image1;
	String pro_image2;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRanking() {
		return ranking;
	}
	public void setRanking(int ranking) {
		this.ranking = ranking;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	public String getpExplan_image1() {
		return pExplan_image1;
	}
	public void setpExplan_image1(String pExplan_image1) {
		this.pExplan_image1 = pExplan_image1;
	}
	public String getpExplan_image2() {
		return pExplan_image2;
	}
	public void setpExplan_image2(String pExplan_image2) {
		this.pExplan_image2 = pExplan_image2;
	}
	public String getpExplan_image3() {
		return pExplan_image3;
	}
	public void setpExplan_image3(String pExplan_image3) {
		this.pExplan_image3 = pExplan_image3;
	}
	public String getPro_image1() {
		return pro_image1;
	}
	public void setPro_image1(String pro_image1) {
		this.pro_image1 = pro_image1;
	}
	public String getPro_image2() {
		return pro_image2;
	}
	public void setPro_image2(String pro_image2) {
		this.pro_image2 = pro_image2;
	}

	@Override
	public String toString() {
		return "NotebookDTO [id=" + id + ", ranking=" + ranking + ", name=" + name + ", gpa=" + gpa
				+ ", pExplan_image1=" + pExplan_image1 + ", pExplan_image2=" + pExplan_image2 + ", pExplan_image3="
				+ pExplan_image3 + ", pro_image1=" + pro_image1 + ", pro_image2=" + pro_image2 + "]";
	}
}
