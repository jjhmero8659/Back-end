package com.junhada.dto;

import java.time.LocalDate;
import lombok.*;

@Setter
@Getter
@ToString
public class ArticleDTO {
	int id;
	int product_id;
	String category;
	String nickName;
	String title;
	String summary;
	int good_rec;
	int bad_rec;
	int inquiry;
	LocalDate date;
	String review_img1;
	String review_img2;
	String review_img3;
	String review_img4;
	String review_img5;
	
}
