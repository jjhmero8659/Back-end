package com.junhada.dto;
import lombok.*;

@Setter
@Getter
@ToString

public class ProductDTO {
	int id;
	int ranking;
	String category;
	String name;
	double gpa;
	String pExplan_image1;
	String pExplan_image2;
	String pExplan_image3;
	String pro_image1;
	String pro_image2;
	String iframe1;
	String iframe2;
	String haemil;
	String wemake;
	String interpark;
	String _11st;
	String lotte;
	String auction;
	String gmarcket;
	String tmon;
	String ssg;
	String coupang;
}
