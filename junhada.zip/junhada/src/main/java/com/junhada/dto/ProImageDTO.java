package com.junhada.dto;
import lombok.*;

@Setter
@Getter
@ToString
public class ProImageDTO {
	String pro_image1;
	String pro_image2;
	String name;
}
