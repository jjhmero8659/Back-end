package com.junhada.dto;
import lombok.*;

@Setter
@Getter
@ToString
public class LoginDTO {
	String id;
	String passwd;
	String nickName;
}
