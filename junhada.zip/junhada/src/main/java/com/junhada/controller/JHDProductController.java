package com.junhada.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.junhada.dto.ArticleDTO;
import com.junhada.dto.ProImageDTO;
import com.junhada.dto.ProductDTO;
import com.junhada.service.JunhadaService;

@RestController
@CrossOrigin("*")
public class JHDProductController {
	@Autowired
	private JunhadaService junhadaService;
	
	@GetMapping("/product/image")
	public ProImageDTO getProductImage(@RequestParam("id") Integer id) {
		return junhadaService.getProductImage(id);
	}
	
	
	@GetMapping("/product/detail")
	public ProductDTO getOneProduct(@RequestParam("id") Integer id, @RequestParam("view") String view) {
		return junhadaService.getOneProduct(id, view);
	}
	
	@GetMapping("/product/representreview")
	public List<ArticleDTO> getProductPrice(@RequestParam("id") Integer id, @RequestParam("view") String view) {
		return junhadaService.getRepresentReview(id, view);
	}
	
	@GetMapping("/product/article")
	public List<ArticleDTO> getProductArticle(@RequestParam("id") Integer id) {
		return junhadaService.getProArticleAll(id);
	}
	
	@GetMapping("/product/list")
	public List<ProductDTO> getAllProduct(@RequestParam("view") String view) {
		return junhadaService.getAllProduct(view);
	}
}
