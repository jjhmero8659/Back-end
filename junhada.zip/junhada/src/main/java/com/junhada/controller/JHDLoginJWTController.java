package com.junhada.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.junhada.security.JwtUtil;
import com.junhada.service.JunhadaService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class JHDLoginJWTController {
	@Autowired
	private JunhadaService junhadaService;
	
	//임시
//	@Autowired
//	private JwtUtil jwtUtil;
	
	@GetMapping("/membership")
	public void getProductImage(@RequestParam("subject") String subject) {
		System.out.println(subject);

	}
	
	
}
