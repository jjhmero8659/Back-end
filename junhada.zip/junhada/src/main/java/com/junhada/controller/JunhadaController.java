package com.junhada.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.junhada.dto.ProductDTO;
import com.junhada.dto.ArticleDTO;
import com.junhada.dto.ProImageDTO;
import com.junhada.service.JunhadaService;

 
@RestController("/")
@CrossOrigin("*")
public class JunhadaController {

	@Autowired
	private JunhadaService junhadaService;
	

	@PutMapping("/inquiry")
	public void addReviewInquiry(@RequestParam("id") Integer id, @RequestParam("view") String view) {
		junhadaService.addInquiry(id, view);
	}
	
	@GetMapping("/profileimage")
	public String getProfileImage(@RequestParam("nickName") String nickName) {
		return junhadaService.getUserProfileImage(nickName);
	}
	
	@GetMapping("/post/information")
	public ArticleDTO getArticleInfo(@RequestParam("id") Integer id) {
		return junhadaService.getArticleInfo(id);
	}

	
	@GetMapping("/login")
	public String checkLogin(@RequestParam("id") String id, @RequestParam("password") String password) {
		return junhadaService.checkLogin(id, password);
	}
	
}
