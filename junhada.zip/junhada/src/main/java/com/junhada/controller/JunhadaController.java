package com.junhada.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.junhada.dto.PriceDTO;
import com.junhada.dto.ProductDTO;
import com.junhada.service.JunhadaService;

 
@RestController
@CrossOrigin("*")
public class JunhadaController {

	@Autowired
	private JunhadaService junhadaService;
	
	
	//React 요청
	@GetMapping("/product/detail")
	public ProductDTO getOneProduct(@RequestParam("id") Integer id, @RequestParam("view") String view) {
		return junhadaService.getOneProduct(id, view);
	}
	
	@GetMapping("/product/price")
	public PriceDTO getProductPrice(@RequestParam("id") Integer id, @RequestParam("view") String view) {
		return junhadaService.getProductPrice(id, view);
	}
	
}
