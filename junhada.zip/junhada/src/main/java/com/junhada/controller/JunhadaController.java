package com.junhada.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.junhada.dto.NotebookDTO;
import com.junhada.service.JunhadaService;

 
@RestController
@CrossOrigin("*")
public class JunhadaController {

	@Autowired
	private JunhadaService junhadaService;
	
	
	//React 요청
	@PostMapping("/MenuScreen")
	public String TestReact( @RequestBody NotebookDTO notebookDTO) {
		System.out.println(notebookDTO);
		return "/MenuScreen";
	}
	
}
