package com.junhada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunhadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunhadaApplication.class, args);
	}

}
