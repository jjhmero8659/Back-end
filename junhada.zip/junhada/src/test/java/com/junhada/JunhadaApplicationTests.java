package com.junhada;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.junhada.JPA.Member;
import com.junhada.JPA.MemberRepository;

@SpringBootTest
class JunhadaApplicationTests {
	
	@Autowired
	MemberRepository memberRepository;

	@Test
	@Transactional
	void contextLoads() {
		Member member = new Member();
		member.setUserName("memberA");
		
		Long savedId = memberRepository.save(member);
		Member findMember = memberRepository.find(savedId);
		System.out.println(findMember.getUserName());
		
		
	}

}
