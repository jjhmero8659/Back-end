package com.junhada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunhadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
